#include<stdio.h>

void main(){

	//

}
